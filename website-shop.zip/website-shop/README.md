สอน https://www.youtube.com/watch?v=bgy6GOZCLhk
เครดิต https://discord.gg/bEyMzxRAx3
